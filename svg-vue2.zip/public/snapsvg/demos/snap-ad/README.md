snap-ad
=======

Snap.svg banner ad

run
`npm install` 
to add node modules


run
`grunt`
to build