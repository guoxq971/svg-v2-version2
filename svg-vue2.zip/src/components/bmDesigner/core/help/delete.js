import { designApplication } from "../dom";

// 删除
export function del() {
  designApplication.designG.remove();
}
