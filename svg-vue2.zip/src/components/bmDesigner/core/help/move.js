import { designApplication } from "@/components/bmDesigner/core/dom";

// 图片移动
export class move {
  // 拖拽开始
  static start(x, y, event) {
    let { e, f } = designApplication.designBd.attr("transform").localMatrix;
    designApplication.designBd.org_e = e; //初始e
    designApplication.designBd.org_f = f; //初始f
  }
  // 拖拽中
  static move(dx, dy, x, y, event) {
    let matrix = designApplication.designBd.attr("transform").localMatrix;
    matrix.e = designApplication.designBd.org_e + dx; //初始x
    matrix.f = designApplication.designBd.org_f + dy; //初始f
    designApplication.designBd.attr("transform", matrix);
    designApplication.editBd.attr("transform", matrix);
  }
  // 拖拽结束
  static end(event) {
    // zoom用到
    const { cx, cy } = designApplication.designBd.getBBox();
    designApplication.designBd.attr({
      last_cx: cx,
      last_cy: cy,
    });
  }
}
