import { designApplication } from "@/components/bmDesigner/core/dom";

export class useDesign {
  /*
   * 旋转设计图
   * @param {number} angle 旋转角度
   * */
  static rotate(angle) {
    let imgBBox = designApplication.designImg.getBBox();
    // 图片矩阵
    let IM = designApplication.designBd.attr("transform").localMatrix;
    let EM = designApplication.editBd.attr("transform").localMatrix;
    // 矩阵以angle为角度, cx,cy 为transform-origin 进行一次旋转变化
    IM.rotate(angle, imgBBox.cx, imgBBox.cy);
    EM.rotate(angle, imgBBox.cx, imgBBox.cy);
    // 设置变化后的矩阵
    designApplication.designBd.attr("transform", IM);
    designApplication.editBd.attr("transform", EM);
  }
}
