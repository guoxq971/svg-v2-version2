import { move } from "@/components/bmDesigner/core/help/move";
import { zoom } from "@/components/bmDesigner/core/help/zoom";
import { rotate } from "@/components/bmDesigner/core/help/rotate";
import { del } from "@/components/bmDesigner/core/help/delete";
import { HelpUtil } from "@/components/bmDesigner/core/help/util";

export class designApplication {
  // 配置
  static config = {
    // [预览模式(preview), 设计模式(edit), 开发模式(dev)]
    mode: "preview",
  };
  // svg 容器
  static svgContainer;

  // svg
  static svg;
  // 设计图最外层
  static designG;
  // 设计图边框
  static designBd;
  // 设计图
  static designImg;
  // 编辑边框
  static editBd;
  // 编辑rect
  static editRect;
  // 编辑 move
  static editMove;
  // 编辑 zoom
  static editZoom;
  // 编辑 rotate
  static editRotate;
  // 编辑 delete
  static editDelete;

  //设计器最外层
  static g;
  // 产品图
  static productImg;
  // 背景图
  static bgImg;
  // 设计区域的填充
  static editAreaFillPath;
  // 设计区域的虚线
  static editAreaDashedPath;
  // 设计区域的rect
  static editAreaRect;
  // 设计图组
  static designGroup;
  // 背景rect
  static bgRect;

  // 裁剪 d1
  static clipD1;
  // 裁剪 d2
  static clipD2;

  // 设置 svg 容器
  static setSvgContainer(svgContainer) {
    this.svgContainer = svgContainer;
  }

  // 设置模式为 预览模式
  static setPreviewMode() {
    this.config.mode = "preview";
    this.editAreaFillPath.node.style.display = "none";
    this.editAreaRect.node.style.display = "none";
    this.editAreaDashedPath.node.style.display = "none";
    this.productImg.node.style.display = "inline";
    this.bgImg.node.style.display = "inline";
  }
  // 设置模式为 设计模式
  static setEditMode() {
    this.config.mode = "edit";
    this.editAreaFillPath.node.style.display = "inline";
    this.editAreaRect.node.style.display = "inline";
    this.editAreaDashedPath.node.style.display = "inline";
    this.productImg.node.style.display = "none";
    this.bgImg.node.style.display = "none";
  }
  // 设置模式为 开发
  static setDevMode() {
    this.config.mode = "dev";
    this.editAreaFillPath.node.style.display = "inline";
    this.editAreaRect.node.style.display = "inline";
    this.editAreaDashedPath.node.style.display = "inline";
    this.productImg.node.style.display = "inline";
    this.bgImg.node.style.display = "inline";
  }

  // dom初始化
  static init(product) {
    // 创建一个 svg
    designApplication.svg = Snap(544, 544).attr({
      viewBox: "0 0 500 500",
      style: "border:1px dotted green;",
    });
    // 加载 svg 在指定容器内
    designApplication.svgContainer.appendChild(designApplication.svg.node);
    // 初始化 svg 内所需要的 dom
    this.domInit(product);
    // 移动 g 到中心位置
    let svgBbox = this.svg.getBBox();
    this.moveToCenter(
      [this.editAreaFillPath, this.editAreaRect, this.editAreaDashedPath],
      svgBbox.cx,
      svgBbox.cy
    );

    this.setPreviewMode();
    // this.setEditMode();
    // this.setDevMode();

    return designApplication.svg;
  }

  // 初始化所有dom
  static domInit(product) {
    // clip id-1
    designApplication.clipD1 = designApplication
      .createClipPath("test")
      .attr("test", "预览模式-d1")
      .toDefs()
      .add(designApplication.svg.paper.path().attr("d", product.d1));
    // clip id-2
    designApplication.clipD2 = designApplication
      .createClipPath("test2")
      .attr("test", "设计模式-d2")
      .toDefs()
      .add(designApplication.svg.paper.path().attr("d", product.d2));
    // 整体元素 --start
    designApplication.g = designApplication.svg
      .g()
      .attr({ test: "设计器最外层" });
    designApplication.productImg = designApplication.svg
      .image(product.productImg, 0, 0, 500, 500)
      .attr({ test: "产品图" });
    designApplication.bgImg = designApplication.svg
      .image(product.bgImg, 0, 0, 500, 500)
      .attr({ test: "背景图" });
    designApplication.editAreaFillPath = designApplication.svg.paper
      .path()
      .attr({
        test: "绘制区域的填充[边框的描边红色虚线]-设计模式-d2",
        d: product.d2,
        fill: "#ffffff",
        stroke: "#ff0000",
        style: "stroke-width:2;stroke-dasharray: 5; display: none;",
      });
    designApplication.editAreaDashedPath = designApplication.svg.paper
      .path()
      .attr({
        test: "绘制区域的虚线[产品的红色虚线]-设计模式-d3",
        d: product.d3,
        fill: "none",
        stroke: "red",
        style: "stroke-width:1.8;stroke-dasharray:5;display: none;",
      });
    let bbox = designApplication.editAreaDashedPath.getBBox();
    designApplication.editAreaRect = designApplication.svg.paper.rect().attr({
      test: "绘制区域的rect[边框的描边黑色虚线]-设计模式-rect",
      x: bbox.x,
      y: bbox.y,
      width: +bbox.width + 2,
      height: +bbox.height + 2,
      fill: "none",
      stroke: "rgb(0, 0, 0)",
      style: "stroke-dasharray: 2;display: none;",
    });
    designApplication.designGroup = designApplication.svg.paper
      .g()
      .attr("test", "设计图group");
    // 整体元素 --end
    // 按顺序渲染在 svg 内
    designApplication.g.add(
      designApplication.editAreaFillPath,
      designApplication.bgImg,
      designApplication.designGroup,
      designApplication.productImg,
      designApplication.editAreaRect,
      designApplication.editAreaDashedPath
    );
  }

  // 创建一组设计图(点击设计图的时候调用这个)
  static createDesignPic() {
    this.designG = this.svg.paper.g().attr({ test: "设计图最外层g" });
    this.designBd = this.svg.paper.g().attr({ test: "设计图的边框" });
    this.editBd = this.svg.paper.g().attr({ test: "编辑的边框" });
    this.designG.add(this.designBd, this.editBd);
    this.designImg = this.svg.paper
      .image(require("../banner1.jpg"), 0, 0, 100, 100)
      .attr({ test: "设计图" });
    this.designBd.add(this.designImg);
    this.editRect = this.svg.paper.rect(0, 0, 100, 100);
    this.editBd.add(this.editRect);
    this.editRect.attr({ test: "编辑的矩形", stroke: "#000", fill: "none" });
    this.editMove = this.svg.paper
      .image(require("../img/move.png"), -18, -18, 18, 18)
      .attr({ test: "编辑移动" });
    this.editBd.add(this.editMove);
    this.editRotate = this.svg.paper
      .image(require("../img/rotating.png"), 100, -18, 18, 18)
      .attr({ test: "编辑旋转" });
    this.editBd.add(this.editRotate);
    this.editZoom = this.svg.paper
      .image(require("../img/zoom.png"), 100, 100, 18, 18)
      .attr({ test: "编辑缩放" });
    this.editBd.add(this.editZoom);
    this.editDelete = this.svg.paper
      .image(require("../img/delete.png"), -18, 100, 18, 18)
      .attr({ test: "编辑删除" });
    this.editBd.add(this.editDelete);
  }

  // 事件绑定
  static methodsInit() {
    // 移动
    this.designBd.drag(move.move, move.start, move.end);
    // 缩放
    this.editZoom.drag(zoom.move, zoom.start, zoom.end);
    // 旋转
    this.editRotate.drag(rotate.move, rotate.start, rotate.end);
    // 删除
    this.editDelete.click(del);
  }

  // 创建 svg 元素
  static createClipPath(id) {
    let dom = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "clipPath"
    );
    dom.setAttribute("id", id);
    this.svg.node.appendChild(dom);
    return Snap(`#${id}`);
  }

  // 将 SNode 移动到指定中心点
  static moveToCenter(SNode, x, y) {
    if (Snap.is(SNode, "array")) {
      SNode.forEach((item) => {
        let bbox = item.getBBox();
        let M = item.attr("transform").localMatrix;
        M.translate(x - bbox.x - bbox.width / 2, y - bbox.y - bbox.height / 2);
        item.attr({ transform: M });
      });
    } else {
      let bbox = SNode.getBBox();
      let M = SNode.attr("transform").localMatrix;
      M.translate(x - bbox.x - bbox.width / 2, y - bbox.y - bbox.height / 2);
      SNode.attr({ transform: M });
    }
  }
}
