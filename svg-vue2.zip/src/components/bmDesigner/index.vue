<template>
  <div class="bm-design-group">
    <div class="flow-container">
      <div class="btn-group">
        <el-button type="primary">选择产品</el-button>
        <el-button>选择图片</el-button>
        <el-button>选择背景</el-button>
        <el-button>添加文字</el-button>
      </div>
      <div class="show-btn">
        <el-tabs v-model="activeName">
          <el-tab-pane label="通用产品" name="1">
            <bmSearchList :list="productList" />
          </el-tab-pane>
          <el-tab-pane label="FBA专用产品" name="2">FBA专用产品</el-tab-pane>
          <el-tab-pane label="收藏产品" name="3">收藏产品</el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <div class="operator-wrap">
      <!-- 中间-设计器 -->
      <div class="design-container">
        <div class="title-wrap">
          <div class="title">(2317)女款撞色T恤-棉烫印</div>
          <el-button type="text">查看详情 ></el-button>
        </div>
        <!-- 基本信息 -->
        <bmInfo style="margin-bottom: 15px" />
        <!-- 设计区域 -->
        <div class="design-wrap">
          <div class="left-wrap">
            <div
              class="item-list"
              :class="{ action: item === 1 }"
              v-for="item in 3"
            ></div>
          </div>
          <div
            class="design-wrap"
            style="width: 750px; height: 550px"
            ref="designBd"
          ></div>
        </div>
      </div>
      <!-- 右侧-操作 -->
      <div class="operator-container">
        <div class="btn-group">
          <div class="btn-1">
            <el-button>设计说明</el-button>
            <el-button>快捷键</el-button>
            <el-button>记录</el-button>
            <el-button>全颜色合成</el-button>
            <el-button>保存产品</el-button>
          </div>
          <div class="btn-2">
            <el-button>撤回</el-button>
            <el-button>前进</el-button>
            <el-button>清空</el-button>
            <el-button>关闭图层</el-button>
            <el-button>开启收藏</el-button>
          </div>
        </div>
        <!-- 图层 -->
        <div class="layer-group">
          <div class="item-layer" v-for="item in designList" :key="item.id">
            <div class="img">
              <img src="./banner1.jpg" style="height: 25px" alt="" />
            </div>
            <div class="name">{{ item.name }}</div>
            <div class="btn-layer">
              <el-button class="item-btn">编辑</el-button>
              <el-button class="item-btn">收藏</el-button>
              <el-button class="item-btn">上移</el-button>
              <el-button class="item-btn">下移</el-button>
              <el-button class="item-btn">切换</el-button>
              <el-button class="item-btn">删除</el-button>
            </div>
          </div>
        </div>
        <!-- 图层-按钮 -->
        <div class="layer-btn-group">
          <div class="btn-1">
            <el-button class="item-btn">置顶</el-button>
            <el-button class="item-btn">置底</el-button>
            <el-button class="item-btn">上移</el-button>
            <el-button class="item-btn">下移</el-button>
            <el-button class="item-btn">复制</el-button>
            <el-button class="item-btn">删除</el-button>
          </div>
          <div class="btn-2">
            <el-button class="item-btn">水平居中</el-button>
            <el-button class="item-btn">垂直居中</el-button>
            <el-button class="item-btn">水平翻转</el-button>
            <el-button class="item-btn">垂直翻转</el-button>
            <el-button class="item-btn">等比放大</el-button>
            <el-button class="item-btn">等比缩小</el-button>
            <el-button class="item-btn" @click="handlerRotate('left')"
              >左旋45°</el-button
            >
            <el-button class="item-btn" @click="handlerRotate('right')"
              >右旋45°</el-button
            >
            <el-button class="item-btn">宽度最大</el-button>
            <el-button class="item-btn">宽度最小</el-button>
            <el-button class="item-btn">最大化</el-button>
            <div class="item-btn"></div>
          </div>
        </div>
        <!-- 多角度 -->
        <div class="multi-angle">
          <bmSwiper />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import bmSwiper from "./bmSwiper.vue";
import bmInfo from "./bmInfo.vue";
import bmSearchList from "./bmSearchList.vue";
import { designApplication } from "@/components/bmDesigner/core/dom";
import { useDesign } from "@/components/bmDesigner/core/help/useDesign";
import { mock } from "@/components/bmDesigner/mock";

export default {
  components: { bmSwiper, bmInfo, bmSearchList },
  data() {
    return {
      // 产品列表
      productList: mock.productList(),
      designList: Array.from({ length: 4 }).map((item, index) => {
        return {
          id: index,
          name: `设计图名字${index}`,
          img: require("./banner1.jpg"),
          isCollect: index !== 1,
          width: 100,
          height: 100,
        };
      }),
      svg: null,
      activeName: "1",
    };
  },
  methods: {
    // 左/右旋
    handlerRotate(type) {
      let angle = { left: -45, right: 45 }[type];
      useDesign.rotate(angle);
    },
  },
  mounted() {
    designApplication.setSvgContainer(this.$refs.designBd);
    designApplication.init(this.productList[1]);
  },
};
</script>

<style scoped lang="scss">
@import "./index.scss";
</style>
