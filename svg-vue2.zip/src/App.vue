<template>
  <div id="app">
    <designer />
  </div>
</template>

<script>
import designer from "@/components/bmDesigner";
export default {
  components: {
    designer,
  },
  data() {
    return {};
  },
  mounted() {},
};
</script>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
}
</style>
